# Personal Portfolio Design Guideline

> 로컬 개발 참고 문서입니다. Git에는 포함하지 않습니다.  
> 레퍼런스: GetQuoti.ai의 시각적 문법과 인터랙션을 분석하되 로고, 카피, 이미지, 고유 그래픽은 복제하지 않습니다.

## 0. 기준과 표기

- **확인값**: 레퍼런스 공개 CSS 또는 실제 화면에서 직접 확인한 항목
- **관찰값**: 화면 캡처와 브라우저 동작에서 관찰한 패턴
- **구현값**: 개인 포트폴리오에 맞춰 새로 정한 값
- 레퍼런스의 브랜드 자산·고유 카피·상표는 사용하지 않습니다.
- 폰트는 라이선스가 명확한 무료 대체 폰트만 사용합니다.
- Mobile-first, 키보드 접근성, 모션 감소 설정을 기본으로 합니다.

## 1. Design Concept

| 항목 | 가이드 |
|---|---|
| 스타일 | 에디토리얼 브루탈리즘과 제품 중심 포트폴리오의 결합 |
| 분위기 | 대담함, 명료함, 실험성, 신뢰감 |
| 핵심 키워드 | Bold / Editorial / Systematic / Kinetic / Human |
| 개인화 방향 | Quoti의 대비와 리듬만 참고하고 UX 문제 정의와 판단 과정을 중심 콘텐츠로 구성 |

## 2. Color System

| 토큰 | HEX | 권장 비율 | 역할 | 구분 |
|---|---:|---:|---|---|
| `--color-black` | `#252322` | 35% | 기본 배경·본문색 | 확인값 기반 |
| `--color-off-white` | `#F0ECE8` | 45% | 밝은 섹션·헤더 | 확인값 기반 |
| `--color-brand-orange` | `#FD5B2C` | 12% | CTA·강조·상태 표시 | 확인값 기반 |
| `--color-brand-purple` | `#7D5BA6` | 5% | 보조 강조·포스터 | 확인값 기반 |
| `--color-brand-green` | `#8BA02C` | 3% | 선택적 보조 포인트 | 확인값 기반 |

- 비율은 전체 페이지의 권장 면적 비율이며 정확한 원본 측정값이 아닙니다.
- 긴 본문은 오렌지 배경 위에 배치하지 않고 명도 대비를 우선합니다.
- 실제 변수의 단일 기준은 `styles.css`의 `@layer tokens`입니다.

## 3. Typography

| 용도 | 패밀리 | 크기 | 굵기 | 행간 | 자간 |
|---|---|---|---|---|---|
| Display | Anton | `clamp(3rem, 13vw, 10.25rem)` | 400 | 0.9 | `-0.045em` |
| H1 | Anton | `clamp(2.75rem, 10vw, 7rem)` | 400 | 0.88–0.9 | `-0.045em` |
| H2 | Anton | `clamp(2.25rem, 7vw, 4.75rem)` | 400 | 0.98 | `-0.03em` |
| 국문 전체 | Pretendard Variable | 요소별 토큰 사용 | 45–920 | 요소별 토큰 사용 | 요소별 토큰 사용 |
| 영문 Body | Switzer | `clamp(1rem, 1.2vw, 1.1875rem)` | 500 | 1.65 | `-0.005em` |
| Label | Geist Mono fallback | `0.8125rem` | 700 | 1.3 | `0.04em` |

- Anton은 SIL Open Font License 계열의 무료 웹폰트입니다.
- Switzer는 Fontshare 배포 조건을 따르는 무료 대체 폰트입니다.
- 국문은 Pretendard Variable을 기본으로 사용합니다. 영문과 숫자는 Switzer를 우선 사용하고, 한글 글리프는 Pretendard로 자동 대체됩니다.
- Pretendard를 불러오지 못할 경우 시스템 sans-serif를 fallback으로 사용합니다.
- 레퍼런스의 유료 또는 라이선스 불명 폰트는 사용하지 않습니다.

## 4. Layout System

| 항목 | 구현 규칙 |
|---|---|
| Container | 최대 `90rem`, 좌우 자동 정렬 |
| Grid | Mobile 4열 / Tablet 8열 / Desktop 12열 |
| Gutter | Mobile `1.25rem` / Tablet `2rem` / Desktop `4rem` |
| Section spacing | `clamp(4.5rem, 12vw, 10rem)` |
| XL spacing | `clamp(6rem, 16vw, 15rem)` |
| Alignment | 카피는 좌측 정렬, CTA·메타 정보는 그리드 축에 맞춤 |

## 5. Information Architecture

```text
Header
Hero
Intro / What I Do
Work / Featured Projects
Work Types / More Work
Case Study / Process
Approach / Principles
Skills
About
Contact
Portfolio Bot
```

코드 구조도 이 정보구조와 일치시킵니다.

```text
assets/components/{component}/{component}.css
assets/components/{component}/{component}.js
```

여러 콘텐츠가 공유하는 스타일과 기능은 `assets/common`에서 관리합니다.

## 6. Components

### Horizontal Story

- `horizontal-story`는 Intro 다음에 배치하는 가로형 프로세스 스토리 컴포넌트입니다.
- Desktop에서는 GSAP `ScrollTrigger`가 세로 스크롤을 track의 가로 이동으로 변환하고 viewport를 pin 처리합니다.
- Intro는 sequence 밖의 일반 세로 섹션이며 pin을 적용하지 않습니다.
- Team Overview와 Horizontal Story만 하나의 sequence viewport 안에서 `Team Overview 고정 → 왼쪽 화면 전환 → 내부 가로 탐색` 순서로 연결합니다.
- 월/단계 타이포, 미디어, 설명은 `data-story-parallax` 값에 따라 서로 다른 속도로 이동합니다.
- Mobile에서는 pin을 사용하지 않고 CSS scroll snap 기반의 직접 가로 탐색으로 전환합니다.
- 다음 콘텐츠는 `data-horizontal-item`이 적용된 `<article class="horizontal-story__panel">` 블록을 복제해 추가합니다.
- Unseen의 로고, 영상, 프로젝트 문구는 복제하지 않으며 가로 타임라인·비정형 배치·표기 체계만 개인 포트폴리오 문법으로 재해석합니다.
- 배경 `#E3E3E3`, 선 `#5D5B56`, 보조 회색 `#BEBEBE`는 이 컴포넌트에 한해 허용하는 로컬 색상 예외입니다.

### Team Overview

- Intro 다음에 배치하되 Intro와 분리된 sequence의 첫 번째 panel로 사용합니다.
- 전체 pin과 가로 좌표는 `horizontal-story.js`만 소유하며 Team Overview에서는 별도 ScrollTrigger를 만들지 않습니다.
- Team Overview의 JavaScript는 IntersectionObserver 기반 내부 등장 상태만 제어해 기존 pin과 transform 충돌을 방지합니다.
- 신호등 형태는 교체 예정인 임시 비주얼이며 프로젝트 의미나 정보 전달 역할을 부여하지 않습니다.
- 검은 배경, 대형 제목, 좌우 비대칭 구성만 We Are Direct Contact 섹션에서 참고하고 원본 영상·문구·브랜드 요소는 사용하지 않습니다.

### Header

- 밝은 오프화이트 캡슐형 고정 헤더
- 좌측 개인 브랜드, 중앙 내비게이션, 우측 Resume·Contact CTA
- 모바일에서는 메뉴 버튼과 전체 화면 내비게이션 제공
- 스크롤 방향에 따라 숨김·재노출하며 키보드 Escape 닫기를 지원

### Button

- 최소 터치 영역 `44px`
- Primary는 오렌지, Secondary는 다크 또는 외곽선
- Hover는 색상 변화와 최대 2px 이동만 사용
- 포커스 링을 hover와 별도로 항상 제공

### Project Card

- 문제, 역할, 범위, 도구, 결과 순서로 읽히게 구성
- 장식용 디바이스 화면은 `aria-hidden` 또는 명확한 대체 설명 제공
- Hover 효과가 없어도 모든 정보와 링크를 사용할 수 있어야 함

### Navigation

- 실제 섹션 ID로 연결
- 활성 메뉴를 추가할 경우 색상뿐 아니라 밑줄 또는 상태 속성 병행

### Footer / Contact

- 이메일, GitHub, Resume, Back to top 제공
- 임시 링크는 배포 전에 실제 주소로 교체

## 7. Hero Design

- 카피 구조: 직무 라벨 → 문제 해결 중심 H1 → 설명 → CTA → 핵심 역량
- H1의 한 구절만 포인트 색상으로 강조
- 배경 이미지는 텍스트 가독성을 위해 어두운 그라디언트를 중첩
- 인물 또는 주요 피사체가 텍스트와 충돌하지 않도록 모바일 object-position 조정
- 사용 중인 Hero 이미지는 개인 포트폴리오용 에셋이며 레퍼런스 이미지를 복제하지 않음

## 8. Motion & Interaction

| 콘텐츠 | 인터랙션 | 구현 위치 |
|---|---|---|
| Header | 스크롤 숨김·복귀, 진행 표시, 모바일 메뉴 | `header/header.js` |
| Hero | 이미지 패럴랙스, 등장, 자석 버튼 | `hero/hero.js` |
| Team Overview | sequence 진입 시 내부 콘텐츠 등장 | `team-overview/team-overview.js` |
| Horizontal Story | ScrollTrigger pin, 가로 이동, 요소별 패럴랙스 | `horizontal-story/horizontal-story.js` |
| Work | 프로젝트 미디어 패럴랙스 | `work/work.js` |
| Case Study | 뷰포트 중앙 항목 활성화 | `case-study/case-study.js` |
| About | 포인터 기반 포스터 틸트 | `about/about.js` |
| Portfolio Bot | 패널 토글과 섹션 이동 | `portfolio-bot/portfolio-bot.js` |

- 현재 구현은 네이티브 JavaScript와 IntersectionObserver 기반입니다.
- 레퍼런스 내부에서 GSAP 사용 여부를 확인하지 못한 효과는 GSAP이라고 단정하지 않습니다.
- GSAP 도입 시에도 컴포넌트 내부 timeline과 정리 함수를 사용합니다.
- `prefers-reduced-motion: reduce`에서는 패럴랙스, 틸트, 자동 marquee를 제거합니다.

## 9. Responsive Design

### Mobile: 0–47.99rem

- 4열 그리드, 1열 콘텐츠
- 메뉴 버튼 사용
- 프로젝트 카피와 비주얼 세로 배치
- 터치 상호작용만으로 모든 기능 수행 가능

### Tablet: 48–63.99rem

- 8열 그리드
- 소개·프로젝트·프로세스를 2열 구조로 전환
- 헤더 데스크톱 전환은 `56rem`부터 적용

### Desktop: 64rem 이상

- 12열 그리드
- 프로젝트 카드 비대칭 5:7 또는 7:5 구성
- Hover·포인터 기반 보조 인터랙션 활성화
- 콘텐츠 최대 폭을 제한해 과도한 확장을 방지

## 10. Accessibility

- 본문 텍스트는 WCAG AA 대비를 목표로 합니다.
- 모든 링크·버튼에 `:focus-visible` 외곽선을 제공합니다.
- 모바일 메뉴는 `aria-expanded`, `aria-controls`, Escape 닫기를 지원합니다.
- 장식 이미지는 빈 `alt` 또는 `aria-hidden`을 사용합니다.
- 의미 있는 이미지는 목적을 설명하는 대체 텍스트를 제공합니다.
- 색상만으로 상태를 전달하지 않습니다.
- `prefers-reduced-motion` 사용자의 콘텐츠 가시성을 보장합니다.
- 제목은 H1부터 순차적인 문서 구조를 유지합니다.

## 11. Personal Branding

- Quoti의 로고, 이름, 카피, 고유 일러스트와 화면을 사용하지 않습니다.
- 강한 대비, 둥근 헤더, 큰 제목, 오렌지 포인트 같은 추상적 디자인 원칙만 참고합니다.
- 개인 브랜드 표기는 `DM / CHOI DONGMIN`으로 통일합니다.
- 프로젝트는 결과 이미지보다 문제 정의, 리서치 근거, 설계 판단, 검증 결과를 우선합니다.
- 임시 프로젝트 콘텐츠는 실제 작업 정보가 준비되는 즉시 교체합니다.

## 12. 저작권·정책 체크

- 일반적인 레이아웃, 색 조합, 인터랙션 패턴은 참고할 수 있으나 표현물을 실질적으로 복제하지 않습니다.
- Quoti 상표 또는 제휴를 암시하지 않습니다.
- 레퍼런스 사이트의 이미지, 로고, 문구, 소스 코드를 재배포하지 않습니다.
- 외부 폰트·이미지·아이콘은 각 라이선스를 확인하고 출처 기록을 유지합니다.
- 현재 포트폴리오는 구조와 시각 문법을 개인 콘텐츠에 맞게 재해석한 구현입니다.

## 13. 개발 규칙

1. 토큰의 실제 값은 루트 `styles.css`에서 수정합니다.
2. `portfolio-tokens.css`는 Git에서 제외되는 로컬 참고 스냅샷입니다.
3. 콘텐츠 전용 CSS와 JS는 해당 컴포넌트 폴더에서 수정합니다.
4. 여러 콘텐츠에서 반복되는 기능만 `assets/common`으로 이동합니다.
5. 기존 ID와 클래스명을 변경할 때는 HTML·CSS·JS 참조를 함께 검사합니다.
6. 새 인터랙션은 키보드와 모션 감소 환경에서도 동작해야 합니다.
7. 배포 전 임시 링크, 이메일, 프로젝트 설명을 실제 정보로 교체합니다.
