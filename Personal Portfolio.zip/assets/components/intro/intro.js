import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { initRevealWithin } from "../../common/reveal.js";

gsap.registerPlugin(ScrollTrigger);

function splitLinesIntoCharacters(title, lines) {
  const originalLabel = title.getAttribute("aria-label");
  const originals = [...lines].map((line) => line.textContent ?? "");
  const segmenter = typeof Intl.Segmenter === "function"
    ? new Intl.Segmenter("ko", { granularity: "grapheme" })
    : null;
  const characters = [];

  title.setAttribute("aria-label", originals.join(" ").trim());

  lines.forEach((line, lineIndex) => {
    const segments = segmenter
      ? [...segmenter.segment(originals[lineIndex])].map(({ segment }) => segment)
      : Array.from(originals[lineIndex]);
    const fragment = document.createDocumentFragment();

    line.setAttribute("aria-hidden", "true");

    segments.forEach((character) => {
      if (/^\s+$/u.test(character)) {
        fragment.append(document.createTextNode(character));
        return;
      }

      const characterElement = document.createElement("span");
      characterElement.className = "intro__char";
      characterElement.textContent = character;
      fragment.append(characterElement);
      characters.push(characterElement);
    });

    line.replaceChildren(fragment);
  });

  return {
    characters,
    restore() {
      lines.forEach((line, lineIndex) => {
        line.textContent = originals[lineIndex];
        line.removeAttribute("aria-hidden");
      });

      if (originalLabel === null) title.removeAttribute("aria-label");
      else title.setAttribute("aria-label", originalLabel);
    },
  };
}

export function initIntro({ reduceMotion }) {
  const sequence = document.querySelector("[data-intro-timeline]");
  const viewport = sequence?.querySelector("[data-intro-viewport]");
  const intro = sequence?.querySelector(".intro");
  initRevealWithin(intro, reduceMotion);
  if (!sequence || !viewport || !intro) return;

  const title = intro.querySelector("h2");
  const lines = title?.querySelectorAll(":scope > span") ?? [];
  if (!title || !lines.length) return;

  if (reduceMotion.matches) {
    sequence.classList.add("intro-timeline--static");
    gsap.set(lines, { color: "#11100d" });
    return () => sequence.classList.remove("intro-timeline--static");
  }

  const { characters, restore } = splitLinesIntoCharacters(title, lines);
  const characterDuration = 1 / Math.max(characters.length, 1);
  gsap.set(lines, { color: "#bdb49b" });
  gsap.set(characters, { color: "#bdb49b" });

  const introTimeline = gsap.timeline({
    defaults: { ease: "none" },
    scrollTrigger: {
      trigger: viewport,
      start: "top top",
      end: () => `+=${Math.max(window.innerHeight, intro.offsetHeight)}`,
      pin: viewport,
      pinSpacing: true,
      scrub: 0.6,
      anticipatePin: 1,
      invalidateOnRefresh: true,
      refreshPriority: 2,
    },
  });

  introTimeline.to(characters, {
    color: "#11100d",
    duration: characterDuration,
    stagger: { each: characterDuration },
  }, 0);

  let isActive = true;
  const refreshScrollTrigger = () => {
    if (isActive) ScrollTrigger.refresh();
  };

  document.fonts?.ready.then(refreshScrollTrigger);
  window.addEventListener("load", refreshScrollTrigger, { once: true });

  return () => {
    isActive = false;
    window.removeEventListener("load", refreshScrollTrigger);
    introTimeline.scrollTrigger?.kill();
    introTimeline.kill();
    gsap.set([...lines, ...characters], { clearProps: "color" });
    restore();
  };
}
