import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function initHorizontalStory() {
  const sequence = document.querySelector("[data-intro-story-sequence]");
  const sequenceViewport = sequence?.querySelector("[data-sequence-viewport]");
  const sequenceTrack = sequence?.querySelector("[data-sequence-track]");
  const teamOverview = sequence?.querySelector("[data-team-overview]");
  const section = document.querySelector("[data-horizontal-story]");
  const track = section?.querySelector("[data-horizontal-track]");
  const storyViewport = section?.querySelector(".horizontal-story__viewport");
  const line = section?.querySelector("[data-story-line]");
  const lineTrack = section?.querySelector("[data-story-line-track]");
  const lineReveal = section?.querySelector("[data-story-line-reveal]");
  if (!sequence || !sequenceViewport || !sequenceTrack || !teamOverview || !section || !track || !storyViewport || !line || !lineTrack || !lineReveal) return;

  const parallaxItems = gsap.utils.toArray("[data-story-parallax]", section);
  const media = gsap.matchMedia();

  const lineCursor = () => window.innerWidth * .34;
  const sizeLine = () => {
    lineTrack.style.width = `${track.scrollWidth}px`;
  };
  const revealLine = (offset = 0) => {
    const reveal = Math.min(track.scrollWidth, Math.max(0, offset + lineCursor()));
    const viewBoxWidth = 2400;
    const revealInViewBox = track.scrollWidth ? (reveal / track.scrollWidth) * viewBoxWidth : 0;
    lineReveal.setAttribute("width", `${revealInViewBox}`);
  };

  media.add("(min-width: 48rem)", () => {
    // Move the complete track past the left edge before releasing the pin.
    const distance = () => Math.max(0, track.scrollWidth + 1);
    const teamHold = () => window.innerWidth * .55;
    const teamToStory = () => Math.max(0, section.offsetLeft - teamOverview.offsetLeft);
    const totalDistance = () => teamHold() + teamToStory() + distance();
    const lineState = { offset: 0 };
    sizeLine();
    revealLine();
    const timeline = gsap.timeline({
      defaults: { ease: "none" },
      scrollTrigger: {
        trigger: sequence,
        start: "top top",
        end: () => `+=${totalDistance()}`,
        pin: sequenceViewport,
        scrub: 1,
        anticipatePin: 1,
        invalidateOnRefresh: true,
      },
    });

    timeline.to({}, { duration: teamHold() });
    timeline.to(sequenceTrack, { x: () => -section.offsetLeft, duration: teamToStory() });
    timeline.to(track, { x: () => -distance(), duration: distance() });
    timeline.to(lineTrack, { x: () => -distance(), duration: distance() }, teamHold() + teamToStory());
    timeline.to(
      lineState,
      {
        offset: () => distance(),
        duration: distance(),
        onUpdate: () => revealLine(lineState.offset),
      },
      teamHold() + teamToStory(),
    );
    timeline.fromTo(
      parallaxItems,
      { x: (_, item) => -window.innerWidth * (Number(item.dataset.storyParallax) || 0) * .12 },
      {
        x: (_, item) => window.innerWidth * (Number(item.dataset.storyParallax) || 0) * .12,
        duration: distance(),
      },
      teamHold() + teamToStory(),
    );

    return () => {
      timeline.scrollTrigger?.kill();
      timeline.kill();
      gsap.set([sequenceTrack, track, lineTrack, ...parallaxItems], { clearProps: "transform" });
      lineReveal.setAttribute("width", "0");
      lineTrack.style.removeProperty("width");
    };
  });

  media.add("(max-width: 47.99rem)", () => {
    const updateMobileLine = () => {
      sizeLine();
      lineTrack.style.transform = `translate3d(${-storyViewport.scrollLeft}px, 0, 0)`;
      revealLine(storyViewport.scrollLeft);
    };

    updateMobileLine();
    storyViewport.addEventListener("scroll", updateMobileLine, { passive: true });
    window.addEventListener("resize", updateMobileLine);

    return () => {
      storyViewport.removeEventListener("scroll", updateMobileLine);
      window.removeEventListener("resize", updateMobileLine);
      lineTrack.style.removeProperty("transform");
      lineReveal.setAttribute("width", "0");
      lineTrack.style.removeProperty("width");
    };
  });

  document.fonts?.ready.then(() => ScrollTrigger.refresh());
}
